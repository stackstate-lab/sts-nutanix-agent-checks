
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from typing import Any, Dict, List, Union
from schematics import Model
from schematics.types import BooleanType, DictType, ListType, ModelType, StringType, UnionType
from stackstate_etl.model.stackstate import EVENT_CATEGORY_CHOICES, AnyType


class DataSource(Model):
    name = StringType(required=True)
    module = StringType()
    cls = StringType()
    init = StringType(required=True)


class Query(Model):
    name = StringType(required=True)
    query = StringType(required=True)
    processor = StringType(required=False)
    template_refs = ListType(StringType(), required=True)


class ComponentTemplateSpec(Model):
    name = StringType(required=True)
    component_type = StringType(required=True, serialized_name=u'type')
    uid = StringType(required=True)
    layer = StringType()
    domain = StringType()
    environment = StringType()
    labels = UnionType((StringType, ListType(StringType)), default=[])
    identifiers = UnionType((StringType, ListType(StringType)), default=[])
    relations = UnionType((StringType, ListType(StringType)), default=[])
    custom_properties = UnionType((StringType, DictType(AnyType)), default={

    })
    mergeable = BooleanType(default=False)
    processor = StringType()


class ComponentTemplate(Model):
    name = StringType(required=True)
    selector = StringType(default=None)
    spec = ModelType(ComponentTemplateSpec)
    code = StringType()


class EventSourceLink(Model):
    title = StringType(required=True)
    url = StringType(required=True)


class EventTemplateSpec(Model):
    category = StringType(required=True, choices=EVENT_CATEGORY_CHOICES)
    event_type = StringType(required=True)
    msg_title = StringType(required=True)
    msg_text = StringType(required=True)
    element_identifiers = UnionType(
        (StringType, ListType(StringType)), default=[])
    source = StringType(required=True, default=u'ETL')
    source_links = ListType(ModelType(EventSourceLink, default=[]))
    data = UnionType((StringType, DictType(AnyType)), default={

    })
    tags = UnionType((StringType, ListType(StringType)), default=[])


class EventTemplate(Model):
    name = StringType(required=True)
    selector = StringType(default=None)
    spec = ModelType(EventTemplateSpec)


class HealthTemplateSpec(Model):
    check_id = StringType(required=True)
    check_name = StringType(required=True)
    topo_identifier = StringType(required=True)
    message = StringType(required=False)
    health = StringType(required=True)


class HealthTemplate(Model):
    name = StringType(required=True)
    selector = StringType(default=None)
    spec = ModelType(HealthTemplateSpec)


class MetricTemplateSpec(Model):
    name = StringType(required=True)
    metric_type = StringType(required=True)
    value = StringType(required=True)
    target_uid = StringType(required=True)
    tags = UnionType((StringType, ListType(StringType)), default=[])


class MetricTemplate(Model):
    name = StringType(required=True)
    selector = StringType(default=None)
    spec = ModelType(MetricTemplateSpec)
    code = StringType()


class ProcessorSpec(Model):
    name = StringType(required=True)
    code = StringType()


class Template(Model):
    components = ListType(ModelType(ComponentTemplate), default=[])
    metrics = ListType(ModelType(MetricTemplate), default=[])
    events = ListType(ModelType(EventTemplate), default=[])
    health = ListType(ModelType(HealthTemplate), default=[])


class ETL(Model):
    source = StringType(default=u'Unknown')
    refs = ListType(StringType(), default=[])
    pre_processors = ListType(ModelType(ProcessorSpec), default=[])
    post_processors = ListType(ModelType(ProcessorSpec), default=[])
    datasources = ListType(ModelType(DataSource), default=[])
    queries = ListType(ModelType(Query), default=[])
    template = ModelType(Template)
