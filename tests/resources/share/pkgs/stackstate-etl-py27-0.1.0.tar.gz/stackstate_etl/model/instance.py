
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from schematics import Model
from schematics.types import ModelType, StringType, URLType, IntType
from stackstate_etl.model.etl import ETL


class HealthSyncSpec(Model):
    source_name = StringType(required=True, default=u'static_health')
    stream_id = StringType(required=True)
    expiry_interval_seconds = IntType(required=False, default=0)
    repeat_interval_seconds = IntType(required=False, default=1800)


class StackStateSpec(Model):
    receiver_url = URLType(required=True)
    api_key = StringType(required=True)
    instance_type = StringType()
    instance_url = StringType()
    health_sync = ModelType(HealthSyncSpec, required=False, default=None)
    internal_hostname = StringType(required=True, default=u'localhost')


class InstanceInfo(Model):
    domain = StringType(default=u'ETL')
    layer = StringType(default=u'ETL')
    environment = StringType(default=u'production')
    etl = ModelType(ETL, required=True)


class CliConfiguration(InstanceInfo):
    stackstate = ModelType(StackStateSpec, required=True)
