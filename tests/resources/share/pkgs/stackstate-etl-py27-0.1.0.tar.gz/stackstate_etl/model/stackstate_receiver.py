
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from datetime import datetime
from typing import Any, Dict, List
from schematics import Model
from schematics.transforms import blacklist, wholelist
from schematics.types import BooleanType, DictType, IntType, ListType, ModelType, StringType
from stackstate_etl.model.stackstate import AnyType, Component, Event, HealthCheckState, Relation, TimestampType


class Instance(Model):
    instance_type = StringType(required=True, serialized_name=u'type')
    url = StringType(required=True)

    class Options(object):
        roles = {
            u'public': wholelist(),
        }


class TopologySync(Model):
    start_snapshot = BooleanType(default=True)
    stop_snapshot = BooleanType(default=True)
    instance = ModelType(Instance, required=True)
    delete_ids = ListType(StringType(), default=[])
    components = ListType(ModelType(Component), default=[])
    relations = ListType(ModelType(Relation), default=[])

    class Options(object):
        roles = {
            u'public': wholelist(),
        }


class HealthSyncStartSnapshot(Model):
    expiry_interval_s = IntType()
    repeat_interval_s = IntType(required=True, default=1800)

    class Options(object):
        roles = {
            u'public': blacklist(u'expiry_interval_s'),
        }


class HealthStream(Model):
    urn = StringType(required=True)
    sub_stream_id = StringType()

    class Options(object):
        roles = {
            u'public': blacklist(u'sub_stream_id'),
        }


class HealthSync(Model):
    start_snapshot = ModelType(HealthSyncStartSnapshot, required=True)
    stop_snapshot = DictType(AnyType, required=True, default={

    })
    stream = ModelType(HealthStream, required=True)
    check_states = ListType(ModelType(HealthCheckState), default=[])

    class Options(object):
        roles = {
            u'public': wholelist(),
        }


class ReceiverApi(Model):
    apiKey = StringType(required=True)
    collection_timestamp = TimestampType(required=True)
    internal_hostname = StringType(
        required=True, serialized_name=u'internalHostname')
    events = DictType(ListType(ModelType(Event), default=[]), default={

    })
    metrics = ListType(AnyType(), default=[])
    service_checks = ListType(AnyType(), default=[])
    health = ListType(ModelType(HealthSync), default=[])
    topologies = ListType(ModelType(TopologySync), default=[])

    class Options(object):
        roles = {
            u'public': wholelist(),
        }


class SyncStats(Model):
    components = IntType()
    relations = IntType()
    checks = IntType()
    events = IntType()
    metrics = IntType()
    payloads = ListType(StringType, default=[])
