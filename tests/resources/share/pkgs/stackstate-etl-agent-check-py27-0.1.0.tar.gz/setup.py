# -*- coding: utf-8 -*-
from setuptools import setup
packages = [
    'stackstate_etl_check_processor',
]
package_data = {'': ['*']}
install_requires = [
]
setup_kwargs = {
   'name': 'stackstate-etl-agent-check',
   'version': '0.1.0',
   'description': 'StackState Extract-Transform-Load Agent Check for 4T data ingestion',
   'long_description': 'None',
   'author': 'Ravan Naidoo',
   'author_email': 'rnaidoo@stackstate.com',
   'maintainer': 'None',
   'maintainer_email': 'None',
   'url': 'None',
   'packages': packages,
   'package_data': package_data,
   'install_requires': install_requires,
   'python_requires': '>=2.7, !=3.0.*, !=3.1.*, !=3.2.*, !=3.3.*, !=3.4.*, !=3.5.*, !=3.6.*',
}

setup(**setup_kwargs)
